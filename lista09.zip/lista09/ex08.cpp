#include <stdio.h>
#include <stdlib.h>

void imprimir_matriz(int** matriz, int linhas, int colunas){
     for(int i=0; i < linhas; i++){
          for(int j=0; j < colunas; j++){
               printf("%d\t", matriz[i][j]);
          }
          printf("\n");
     }
}


int main(){
    //OBS: FICOU IGUAL AO ex09.cpp
     int m, n, val;
     int** matriz = NULL;
     
     printf("Informe a quantidade de linhas e colunas:\n");
     printf("Linhas:\n");
     scanf("%d", &m); //linhas
     printf("Colunas:\n");
     scanf("%d", &n); //colunas
     
     matriz = (int**) malloc(m*sizeof(int*));

     if (matriz == NULL){
          printf("ERRO AO ALOCAR!");
          return 1;
     }
     for(int j=0; j < m; j++){
          matriz[j] = (int*) malloc(n*sizeof(int));
          if (matriz[j] == NULL){
               printf("ERRO AO ALOCAR POSICAO %d!", j);
               return 1;
          }
     }

     for(int i=0; i < m; i++){
          for(int j=0; j < n; j++){
               printf("[%d][%d]:\n", i, j);
               scanf("%d", &val);
               matriz[i][j] = val;
          }
     }

     imprimir_matriz(matriz, m, n);
     
     for(int i = 0; i < m; i++){
          free(matriz[i]);
     }
     free(matriz);

     getchar();
     return 0;
}
