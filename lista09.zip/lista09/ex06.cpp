#include <stdio.h>
#include <stdlib.h>

int **alocar_matriz(int linhas, int colunas){
     int **matriz = NULL;
     matriz = (int**)malloc(linhas*sizeof(int*));
     
     if (matriz == NULL) {
          printf("ERRO AO ALOCAR!");
          return NULL;
     }

     for(int i=0; i < linhas; i++){
          matriz[i] = (int*)malloc(colunas*sizeof(int));     
          if (matriz[i] == NULL){
               printf("ERRO AO ALOCAR!");
               return NULL;
          }
     }
          
     return matriz;
}


int main(){
     int m, n;
     
     printf("Informe a quantidade de linhas e colunas:\n");
     scanf("%d", &m); //linhas
     scanf("%d", &n); //colunas
     


     printf("%d ", alocar_matriz(m, n));
     getchar();
     return 0;
}
