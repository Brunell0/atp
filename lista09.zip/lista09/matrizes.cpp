#include <stdio.h>
#include <stdlib.h>

//matrizes e vetores

int main(){
     int vetor[5] = 
     {
          1,2,3,4,5
     };

     int matriz[2][3]=
     {
          {
               10,20,30
          },
          {
               40,50,60
          }
     };
     
     printf("VETOR:\n");
       for(int i = 0; i < 5; i++){
          printf("%d ", vetor[i]);
     }
     
     printf("\nMATRIZ:\n");
     for(int i = 0; i < 2; i++){
          for(int j = 0; j < 3; j++){
               printf("%d ", matriz[i][j]);
          }
          printf("\n");
     }
     getchar();
     return 0;
}