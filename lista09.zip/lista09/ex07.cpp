#include <stdio.h>
#include <stdlib.h>

void liberar_espaco(int** matriz, int linhas){
     for(int i = 0; i < linhas; i++){
          free(matriz[i]);
     }

     free(matriz);
}