#include <stdio.h>
#include <stdlib.h>

void imprimir_matriz(int** matriz, int linhas, int colunas){
     for(int i=0; i < linhas; i++){
          for(int j=0; j < colunas; j++){
               printf("%d\t", matriz[i][j]);
          }
          printf("\n");
     }
}

void produto_vetorial(int** matriz_um, int** matriz_dois, int l, int c, int comum){
    //a variavel comum eh coluna da matriz 1 ou a linha da matriz 2
    int** matriz_resultante = NULL;
    int soma;
    //realoca a matriz resultante com o numero de colunas da matriz 1 e linhas da matriz 2
    matriz_resultante = (int**) malloc(l * sizeof(int*));
    if (matriz_resultante == NULL){
          printf("ERRO AO ALOCAR!");
          exit;
     }
     for(int j=0; j < l; j++){
          matriz_resultante[j] = (int*) malloc(c * sizeof(int));
          if (matriz_resultante[j] == NULL){
               printf("ERRO AO ALOCAR POSICAO %d!", j);
               exit;
          }
     }    
    
    for(int i=0; i < l; i++){
        for(int j=0; j < c; j++){
            soma=0;
            for(int k=0; k < comum; k++){ //efetua a soma de cada elemento ij
                soma += matriz_um[i][k] * matriz_dois[k][j]; 
            }
            matriz_resultante[i][j] = soma;
        }
    }
    
    printf("\nMATRIZ RESULTANTE:\n");
    for(int i=0; i < l; i++){
        for(int j=0; j < c; j++){
            printf("%d\t", matriz_resultante[i][j]);
        }
          printf("\n\n");
    }
    
    for(int i = 0; i < l; i++){
          free(matriz_resultante[i]);
     }
     free(matriz_resultante);
}

int main(){
     int m1, n1, m2, n2, val; //val eh uma variavel temporaria, utilizada para atribuir o valor a posicao correspondente
     int** matriz1 = NULL;
     int** matriz2 = NULL;
     
     printf("Informe a quantidade de linhas e colunas (matriz 1):\n");
     printf("Linhas:\n");
     scanf("%d", &m1); //linhas
     printf("Colunas:\n");
     scanf("%d", &n1); //colunas
     
     matriz1 = (int**) malloc(m1*sizeof(int*));

     if (matriz1 == NULL){
          printf("ERRO AO ALOCAR!");
          return 1;
     }
     for(int j=0; j < m1; j++){
          matriz1[j] = (int*) malloc(n1*sizeof(int));
          if (matriz1[j] == NULL){
               printf("ERRO AO ALOCAR POSICAO %d!", j);
               return 1;
          }
     }

     for(int i=0; i < m1; i++){
          for(int j=0; j < n1; j++){
               printf("[%d][%d]:\n", i, j);
               scanf("%d", &val);
               matriz1[i][j] = val;
          }
     }


    printf("Informe a quantidade de linhas e colunas (matriz 2):\n");
     printf("Linhas:\n");
     scanf("%d", &m2); //linhas
     printf("Colunas:\n");
     scanf("%d", &n2); //colunas
     
     matriz2 = (int**) malloc(m2*sizeof(int*));

     if (matriz2 == NULL){
          printf("ERRO AO ALOCAR!");
          return 1;
     }
     for(int j=0; j < m2; j++){
          matriz2[j] = (int*) malloc(n2*sizeof(int));
          if (matriz2[j] == NULL){
               printf("ERRO AO ALOCAR POSICAO %d!", j);
               return 1;
          }
     }

     for(int i=0; i < m2; i++){
          for(int j=0; j < n2; j++){
               printf("[%d][%d]:\n", i, j);
               scanf("%d", &val);
               matriz2[i][j] = val;
          }
     }
     
     //exibe as matrizes
     printf("\nMATRIZ 1: \n");
     imprimir_matriz(matriz1, m1, n1);
     
     printf("\nMATRIZ 2: \n");
     imprimir_matriz(matriz2, m2, n2);
    
    if (n1 == m2){ //colunas da matriz 1 e linhas da matriz 2
        produto_vetorial(matriz1, matriz2, m1, n2, n1); //o tamanho da matriz resultante sera a linha da matriz 1 e coluna da matriz 2
    }else{
        printf("Impossivel o produto vetorial entre essas matrizes!\n");
    }
    
    for(int i = 0; i < m1; i++){
          free(matriz1[i]);
    }
    for(int i = 0; i < m2; i++){
          free(matriz2[i]);
    }
     free(matriz1);
     free(matriz2);

     getchar();
     return 0;
}