#include <stdio.h>
#include <stdlib.h>

int main(){
     int matriz[3][3] = {{7,32,9}, {0,15,68}, {27,81,19}}, soma = 0;
     
     printf("MATRIZ:\n");
     for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               printf("%d\t", matriz[i][j]);
               if (i == j){
                   soma += matriz[i][j];
               }
          }
          printf("\n");
     }
    
    printf("Soma do elementos da diagonal principal (i=j): \n%d\n", soma);

     for(int i = 0; i < 3; i++){
          free(matriz[i]);
     }
     free(matriz);

     getchar();
     return 0;
}