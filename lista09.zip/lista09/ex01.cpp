#include <stdio.h>
#include <stdlib.h>


int **soma_matrizes(int A[3][3], int B[3][3]){
     int **C = NULL;
     C = (int**)malloc(3*sizeof(int*));

     if (C == NULL) {
          printf("ERRO AO ALOCAR!");
          return NULL;
     }

     for(int i=0; i < 3; i++){
          C[i] = (int*)malloc(3*sizeof(int));
          if (C[i] == NULL) {
               printf("ERRO AO ALOCAR!");
               return NULL;
          }
     }
     
     for(int i=0; i < 3; i++){ 
          for(int j=0; j < 3; j++){
               C[i][j] = A[i][j] + B[i][j];
          }
     }
     return C;
}

/*
int main(){
     int A[3][3]={ {1,2,3}, {3,2,1} };
     int B[3][3]={ {4,5,6}, {6,5,4} };
     
     //int **C = soma_matrizes(A, B);
     printf("%d ", soma_matrizes(A, B));
     getchar();
     return 0;
}
*/