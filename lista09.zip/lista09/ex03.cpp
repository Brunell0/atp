#include <stdio.h>
#include <stdlib.h>

void pertence(int matriz[3][3], int p){
     int existe = 0;
     for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               if(matriz[i][j] == p){
                    printf("posicao: [%d][%d]\n", i, j);
                    existe = 1;
               }
          }
          
     }

     if (!existe)
          printf("O numero %d nao pertence a matriz!\n", p);
}


int main(){
     int matriz[3][3] = {{1,2,3}, {4,5,6}, {7,8,9}}, a;
     
     printf("Digite um numero para ver sua posicao:\n");
     scanf("%d", &a);

     pertence(matriz, a);

     for(int i = 0; i < 3; i++){
          free(matriz[i]);
     }
     free(matriz);

     getchar();
     return 0;
}