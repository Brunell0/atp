#include <stdio.h>
#include <stdlib.h>

int main(){
     int matriz_um[3][3] = {{7,32,9}, {0,15,68}, {27,81,19}};
     int matriz_dois[3][3] = {{47,6,5}, {7,41,6}, {73,8,8}};
     int matriz_resultante[3][3];
     int soma;
     
     printf("MATRIZ UM:\n");
     for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               printf("%d\t", matriz_um[i][j]);
          }
          printf("\n\n");
     }
     
     printf("MATRIZ DOIS:\n");
     for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               printf("%d\t", matriz_dois[i][j]);
          }
          printf("\n\n");
     }
    
    //produto de matrizes
    for(int i=0; i < 3; i++){
        for(int j=0; j < 3; j++){
            soma=0;
            for(int k=0; k < 3; k++){ //efetua a soma de cada elemento ij
                soma += matriz_um[i][k] * matriz_dois[k][j]; 
            }
            matriz_resultante[i][j] = soma;
        }
    }


    printf("MATRIZ RESULTANTE:\n");
    for(int i=0; i < 3; i++){
        for(int j=0; j < 3; j++){
            printf("%d\t", matriz_resultante[i][j]);
        }
          printf("\n\n");
    }
    
     for(int i = 0; i < 3; i++){
          free(matriz_um[i]);
          free(matriz_dois[i]);
     }
     free(matriz_um);
     free(matriz_dois);
     

     getchar();
     return 0;
}