#include <stdio.h>
#include <stdlib.h>

void transposta(int matriz[3][3]){
     printf("\nTRANSPOSTA:\n");
     for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               printf("%d\t", matriz[j][i]);
          }
          printf("\n");
     }
}


int main(){
     int matriz[3][3] = {{1,2,3}, {4,5,6}, {7,8,9}};
     
     printf("MATRIZ:\n");
     for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               printf("%d\t", matriz[i][j]);
          }
          printf("\n");
     }

    
     transposta(matriz);

     for(int i = 0; i < 3; i++){
          free(matriz[i]);
     }
     free(matriz);

     getchar();
     return 0;
}