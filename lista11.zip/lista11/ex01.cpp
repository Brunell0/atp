#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool ehPrimo(int n) {
    if (n <= 1) return false;
    if (n == 2) return true;
    if (n % 2 == 0) return false;

    for (int i = 3; i * i <= n; i += 2)
        if (n % i == 0)
            return false;
    
    return true;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Uso: %s <inicio> <fim>\n", argv[0]);
        return 1;
    }

    int inicio = atoi(argv[1]);
    int fim = atoi(argv[2]);

    if (inicio > fim) {
        printf("O valor de inicio deve ser menor ou igual ao de fim.\n");
        return 1;
    }

    printf("Numeros primos entre %d e %d:\n", inicio, fim);

    for (int i = inicio; i <= fim; i++) {
        if (ehPrimo(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}