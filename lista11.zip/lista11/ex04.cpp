#include <stdio.h>
#include <stdlib.h>

int** alocar_matriz(int n) {
    int** matriz = (int**) malloc(n * sizeof(int*));
    if (matriz == NULL){
        printf("Erro ao alocar matriz!");
        return 0;
    }
    for (int i = 0; i < n; i++) {
        matriz[i] = (int*) malloc(n * sizeof(int));
        if (matriz[i] == NULL){
            printf("Erro ao alocar matriz!");
            return 0;
        }
    }
    return matriz;
}

void liberar_matriz(int** matriz, int n) {
    for (int i = 0; i < n; i++) {
        free(matriz[i]);
    }
    free(matriz);
}

void ler_matriz(FILE* arquivo, int** matriz, int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            fscanf(arquivo, "%d", &matriz[i][j]);
}

void somar_matrizes(int** m1, int** m2, int** resultado, int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            resultado[i][j] = m1[i][j] + m2[i][j];
}

void imprimir_matriz(int** matriz, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            printf("%d\t", matriz[i][j]);
        printf("\n");
    }
}

int main() {
    FILE* arquivo = fopen("matriz.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo matriz.txt.\n");
        return 1;
    }

    int n;
    fscanf(arquivo, "%d", &n);

    int** matriz1 = alocar_matriz(n);
    int** matriz2 = alocar_matriz(n);
    int** resultado = alocar_matriz(n);

    ler_matriz(arquivo, matriz1, n);
    ler_matriz(arquivo, matriz2, n);
    fclose(arquivo);

    somar_matrizes(matriz1, matriz2, resultado, n);

    printf("Resultado da soma das matrizes:\n");
    imprimir_matriz(resultado, n);

    liberar_matriz(matriz1, n);
    liberar_matriz(matriz2, n);
    liberar_matriz(resultado, n);

    return 0;
}
