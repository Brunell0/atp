#include <stdio.h>
#include <math.h>

double arredondar(double valor, int casas) {
    double fator = pow(10.0, casas);
    return round(valor * fator) / fator;
}

int main() {
    double numero;
    int casas;

    printf("Digite um numero: ");
    scanf("%lf", &numero);

    printf("Digite o numero de casas decimais: ");
    scanf("%d", &casas);

    double resultado = arredondar(numero, casas);
    printf("Resultado arredondado: %.*f\n", casas, resultado);

    return 0;
}