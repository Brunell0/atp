#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ITENS 100
#define MAX_NOME   50

int main() {
    FILE *fmenu = fopen("menu.txt", "r");
    if (!fmenu) {
        perror("Erro ao abrir menu.txt");
        return 1;
    }

    int n;
    
    if (fscanf(fmenu, "%d", &n) != 1 || n <= 0 || n > MAX_ITENS) {
        fprintf(stderr, "Formato invalido na primeira linha de menu.txt\n");
        fclose(fmenu);
        return 1;
    }
    fgetc(fmenu);

    char nomes[MAX_ITENS][MAX_NOME];
    float precos[MAX_ITENS];

    for (int i = 0; i < n; i++) {
        char linha[200];
        if (!fgets(linha, sizeof(linha), fmenu)) {
            fprintf(stderr, "Faltam itens em menu.txt (linha %d)\n", i + 2);
            fclose(fmenu);
            return 1;
        }
        
        linha[strcspn(linha, "\r\n")] = '\0';

        
        char *startPreco = strstr(linha, "R$");
        if (!startPreco) {
            fprintf(stderr, "Formato invalido na linha %d: %s\n", i + 2, linha);
            fclose(fmenu);
            return 1;
        }
        
        char precoStr[20];
        int j = 0;
        for (char *p = startPreco + 2; *p && *p != ';'; ++p) {
            if (*p == ',') precoStr[j++] = '.';
            else precoStr[j++] = *p;
        }
        precoStr[j] = '\0';

        *startPreco = '\0';

        int len = strlen(linha);
        if (len > 0 && linha[len-1] == ' ') linha[len-1] = '\0';
        strncpy(nomes[i], linha, MAX_NOME - 1);
        nomes[i][MAX_NOME - 1] = '\0';

        precos[i] = strtof(precoStr, NULL);
    }
    fclose(fmenu);

    int escolha;
    int quantidades[MAX_ITENS] = {0};

    printf("--- Cardapio ---\n");
    printf(" 0) Finalizar pedido\n");
    for (int i = 0; i < n; i++) {
        printf("%2d) %-30s R$ %.2f\n", i + 1, nomes[i], precos[i]);
    }

    do {
        printf("Selecione o item (0 para finalizar): ");
        if (scanf("%d", &escolha) != 1) {
            fprintf(stderr, "Entrada invalida\n");
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
            escolha = -1;
            continue;
        }
        if (escolha > 0 && escolha <= n) {
            int qtd;
            printf("Quantidade de '%s': ", nomes[escolha - 1]);
            if (scanf("%d", &qtd) != 1 || qtd < 0) {
                fprintf(stderr, "Quantidade invalida\n");
                int c;
                while ((c = getchar()) != '\n' && c != EOF);
            } else {
                quantidades[escolha - 1] += qtd;
            }
        } else if (escolha != 0) {
            printf("Opcao invalida\n");
        }
    } while (escolha != 0);

    
    FILE *fb = fopen("boleto.txt", "w");
    if (!fb) {
        perror("Erro ao abrir boleto.txt");
        return 1;
    }

    fprintf(fb, "Boleto de pedido - Lanchonete\n");
    fprintf(fb, "%-30s %10s %12s %12s\n", "Item", "Quantidade", "Preco Un.", "Subtotal");
    fprintf(fb, "----------------------------------------------------------------------------\n");

    float total = 0.0f;
    for (int i = 0; i < n; i++) {
        if (quantidades[i] > 0) {
            float subtotal = quantidades[i] * precos[i];
            fprintf(fb, "%-30s %10d   R$ %7.2f   R$ %9.2f\n",
                    nomes[i], quantidades[i], precos[i], subtotal);
            total += subtotal;
        }
    }
    fprintf(fb, "\nTotal a pagar: R$ %.2f\n", total);
    fclose(fb);

    printf("Boleto gerado em 'boleto.txt' com sucesso!\n");
    return 0;
}
