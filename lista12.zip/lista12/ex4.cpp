#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int valor;
} Decimal;

Decimal iniciar(int parte_inteira, int parte_decimal) {
    Decimal d;
    d.valor = parte_inteira * 10000 + parte_decimal;
    return d;
}

Decimal somar(Decimal a, Decimal b) {
    Decimal res;
    res.valor = a.valor + b.valor;
    return res;
}

Decimal subtrair(Decimal a, Decimal b) {
    Decimal res;
    res.valor = a.valor - b.valor;
    return res;
}

void imprimir(Decimal d) {
    int inteiro = d.valor / 10000;
    int frac = abs(d.valor % 10000);
    printf("%d.%04d\n", inteiro, frac);
}

int main() {
    Decimal x = iniciar(3, 7000);      // 3.7000
    Decimal y = iniciar(2, 5000);      // 2.5000
    Decimal s = somar(x, y);           // 6.2000
    Decimal d = subtrair(x, y);        // 1.2000

    imprimir(x);
    imprimir(y);
    printf("Soma: "); 
    imprimir(s);

    printf("Subtracao: "); 
    imprimir(d);
    return 0;
}
