#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct aluno {
    char nome[100];
    float t1, p1, p2;
    struct aluno *prox;
} Aluno;

Aluno* iniciar(const char *nome, float t1, float p1, float p2) {
    Aluno *a = (Aluno*) malloc(sizeof(Aluno));
    if (a == NULL){
        printf("Erro ao alocar!");
        exit(1);
    }

    strncpy(a->nome, nome, 99);
    a->nome[99] = '\0';
    a->t1 = t1;
    a->p1 = p1;
    a->p2 = p2;
    a->prox = NULL;
    return a;
}

Aluno* adicionar(Aluno *lista, const char *nome, float t1, float p1, float p2) {
    if (!lista) return iniciar(nome, t1, p1, p2);
    if (!lista->prox) return lista->prox = iniciar(nome, t1, p1, p2);
    return adicionar(lista->prox, nome, t1, p1, p2);
}

void calcular_media(Aluno *lista) { //calcula media de todos
    for (Aluno *p = lista; p; p = p->prox) {
        float media = (p->t1 * 0.2) + ((p->p1 * 0.4) + (p->p2 * 0.6)) * 0.8;
        printf("%s: %.2f\n", p->nome, media);
    }
}

void liberar(Aluno *lista) {
    Aluno *temp, *atual = lista;
    while(atual != NULL){
        temp = atual;
        atual = atual->prox;
        free(temp);
    }
}

int main() {
    int n;
    char nome[100];
    float t1, p1, p2;
    Aluno *turma = NULL;

    printf("Quantidade de alunos: \n");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Aluno %d nome: \n", i+1);
        scanf("%s", nome);

        printf("T1: \n");
        scanf("%f", &t1);
        printf("P1: \n");
        scanf("%f", &p1);
        printf("P2: \n");
        scanf("%f", &p2);

        if (!turma) turma = iniciar(nome, t1, p1, p2);
        else adicionar(turma, nome, t1, p1, p2);
    }

    printf("\nMedia dos alunos:\n\n");
    calcular_media(turma);

    liberar(turma);
    return 0;
}