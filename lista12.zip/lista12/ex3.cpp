#include <stdio.h>
#include <stdlib.h>

typedef struct no {
    int valor;
    struct no *direita;
    struct no *abaixo;
} No;


No* iniciar(int l, int c) {
    No *base = (No*) malloc(sizeof(No) * l * c);
    if (base == NULL){
        printf("Erro ao alocar!");
        exit(1);
    }
    for (int i = 0; i < l * c; i++) {
        base[i].valor = 0;
        if (i % c == c - 1) {
            base[i].direita = NULL;
        } else {
            base[i].direita = &base[i + 1];
        }
        if (i / c == l - 1) {
            base[i].abaixo = NULL;
        } else {
            base[i].abaixo = &base[i + c];
        }
    }
    return base;
}

void imprimir(No *mat, int l, int c) {
    for (int i = 0; i < l; i++) {
        No *p = mat + i * c;
        for (int j = 0; j < c; j++) {
            printf("%d ", p->valor);
            p = p->direita;
        }
        printf("\n");
    }
}


void liberar(No *mat) {
    free(mat);
}

int main() {
    int linhas = 4, colunas = 4;
    No *m = iniciar(linhas, colunas);

    m[0].valor = 5;              // [0][0]
    m[1].valor = 7;              // [0][1]
    m[1 + colunas*2].valor = 9;  // [2][1]
    m[0 + colunas*1].valor = 3;  // [1][0]

    imprimir(m, linhas, colunas);
    liberar(m);
    return 0;
}
