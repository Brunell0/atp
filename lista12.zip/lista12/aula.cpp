//#include <stdio.h>
//#include <stdlib.h>

//anotacoes da aula - apenas para estudos

/*
struct Aluno{
    char nome[50], RA[50];
    float nota[3];
};

typedef struct{
    float x, y;
} Ponto;

void imprime_ponto(Ponto p){
    printf("(%.2f, %.2f)\n", p.x, p.y);
}

void escala_ponto(Ponto *p, float escala){
    p->x *= escala;
    p->y *= escala;
}

int main(){
    Ponto p1, p2;

    p1 = {2.5, 3.7};
    p2.x = 4.2;
    p2.y = 1.8;

    escala_ponto(&p1, 10);
    escala_ponto(&p2, 2);

    imprime_ponto(p1);
    imprime_ponto(p2);

    getchar();
    return 0;
}*/

/*
typedef struct no{ //minusculo - estrutura
    int valor;
    struct no *prox;
} No; //maiusculo - tipo

No* iniciar(int valor){
    No* lista = (No*) malloc(sizeof(No));

    if (lista == NULL){
        printf("Erro ao alocar a lista!");
        return NULL;
    }

    lista->valor = valor;
    lista->prox = NULL;
    return lista;
}

void liberar(No* lista){
    No *temp, *atual = lista;
    while(atual != NULL){
        temp = atual;
        atual = atual->prox;
        free(temp);
    }
}

No* adicionar(No* lista, int valor){
    if (lista->prox == NULL){ //final da lista
        No* novo = iniciar(valor);
        lista->prox = novo;
        return novo;
    }else{
        return adicionar(lista->prox, valor); //recursao - vai para o proximo elemento da lista
    }
}

void imprimir(No* lista){
    No *atual = lista;
    while(atual != NULL){
        printf("%d ", atual->valor);
        atual = atual->prox;
    }
}

int main(){
    No* lista = iniciar(1);

    adicionar(lista, 2);
    adicionar(lista, 3);

    imprimir(lista);

    liberar(lista);

    getchar();
    return 0;
}
*/