#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Item {
    char nome[50];
    float preco;
    struct Item *prox;
} Item;

typedef struct {
    Item *inicio;
    int total;
} Cardapio;

Item* criar(const char *nome, float preco) {
    Item *it = (Item*) malloc(sizeof(Item));
    if (it == NULL) { 
        printf("Erro ao alocar!");
        exit(1);
    }
    strncpy(it->nome, nome, 49);
    it->nome[49] = '\0';
    it->preco = preco;
    it->prox = NULL;
    return it;
}

void adicionar(Cardapio *c, Item *it) {
    if (!c->inicio) c->inicio = it;
    else {
        Item *p = c->inicio;
        while (p->prox) p = p->prox;
        p->prox = it;
    }
    c->total++;
}

void mostrar(Cardapio *c) {
    printf("--- Cardapio ---\n");
    printf(" 0) Finalizar pedido\n");
    int i = 1;
    for (Item *p = c->inicio; p; p = p->prox, i++) {
        printf("%2d) %-30s R$ %.2f\n", i, p->nome, p->preco);
    }
}

void liberar(Cardapio *c) {
    Item *p = c->inicio;
    while (p) {
        Item *t = p;
        p = p->prox;
        free(t);
    }
}

int main() {
    FILE *f = fopen("menu.txt", "r");
    if (!f) {
         printf("Erro abrir menu.txt");
         return 1;
    }

    Cardapio menu = { NULL, 0 };
    int n;
    if (fscanf(f, "%d", &n) != 1 || n < 1 || n > 100) { fclose(f); return 1; }
    fgetc(f);

    for (int i = 0; i < n; i++) {
        char linha[200];
        if (!fgets(linha, sizeof(linha), f)) break;
        linha[strcspn(linha, "\r\n")] = '\0';

        char *sep = strstr(linha, "R$");
        if (!sep) continue;
        *sep = '\0';
        float preco = strtof(sep + 2, NULL);

        adicionar(&menu, criar(linha, preco));
    }
    fclose(f);

    int q[100] = {0};
    int escolha;
    do {
        mostrar(&menu);
        printf("Selecione (0 sai): ");
        if (scanf("%d", &escolha) != 1) { escolha = -1; getchar(); continue; }
        if (escolha > 0 && escolha <= menu.total) {
            Item *p = menu.inicio;
            for (int j = 1; j < escolha; j++) p = p->prox;
            int qtd;
            printf("Qtd de %s: ", p->nome);
            scanf("%d", &qtd);
            if (qtd > 0) q[escolha-1] += qtd;
        }
    } while (escolha != 0);

    FILE *b = fopen("boleto.txt", "w");
    fprintf(b, "Boleto de pedido - Lanchonete\n");
    fprintf(b, "%-30s %10s %12s %12s\n", "Item", "Qtd", "Preco U.", "Subtotal");
    fprintf(b, "------------------------------------------------------------\n");

    float total = 0;
    Item *p = menu.inicio;
    for (int i = 0; p; p = p->prox, i++) {
        if (q[i] > 0) {
            float sub = q[i] * p->preco;
            fprintf(b, "%-30s %10d R$ %7.2f R$ %9.2f\n", p->nome, q[i], p->preco, sub);
            total += sub;
        }
    }
    fprintf(b, "\nTotal a pagar: R$ %.2f\n", total);
    fclose(b);

    printf("Boleto gerado em 'boleto.txt'\n");
    liberar(&menu);
    return 0;
}