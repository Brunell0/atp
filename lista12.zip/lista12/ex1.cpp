#include <stdio.h>
#include <stdlib.h>

typedef struct{
    char nome[50];
    float t1, p1, p2;
}Aluno;

float calcular_media(Aluno *aluno){
    float media = (aluno->t1 * 0.2) + ((aluno->p1 * 0.4) + (aluno->p2 * 0.6)) * 0.8;
    return media;
}

int main(){
    Aluno aluno;

    printf("Digite as notas:\n");
    printf("Trabalho:\n");
    scanf("%f", &aluno.t1);
    printf("Prova 1:\n");
    scanf("%f", &aluno.p1);
    printf("Prova 2:\n");
    scanf("%f", &aluno.p2);
    
    printf("%.2f", calcular_media(&aluno));

    getchar();
    return 0;
}