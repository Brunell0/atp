#include <stdio.h>
#include <stdlib.h>

int main(){
     int* vetor = NULL;
     int tam;
     printf("Digite o tamanho do array:\n");
     scanf("%d",&tam);
     
     vetor = (int*) malloc(tam * sizeof(int));
     if (vetor == NULL){
          printf("ERRO AO ALOCAR");
          return 1;
     }

     for(int i=0; i < tam; i++){
          printf("Digite a posicao %d: \n", i+1);
          scanf("%d", &vetor[i]);
     }

     for(int j=0; j < tam; j++){
          printf("Vetor [%d] = %d\n", j, vetor[j]);
     }

     tam /= 2;
     realloc(vetor, tam * sizeof(int));
     printf("\nMetade do array:\n\n");
     for(int j=0; j < tam; j++){
          printf("Vetor [%d] = %d\n", j, vetor[j]);
     }

     free(vetor);
     getchar();
     return 0;
}