#include <stdio.h>
#include <stdlib.h>

 int main(){
    int* v = NULL;
    int n = 9;
    v = (int*) calloc(n, sizeof(int));

    if(v == NULL) return 1; //verifica se o alocamento funcionou

    for(int i=0; i < 3; i++){
          for(int j=0; j < 3; j++){
               printf("%d ", v[i*3+j]);     
          }
          printf("\n");          
    }

    free(v);
    getchar();
    return 0;
 }