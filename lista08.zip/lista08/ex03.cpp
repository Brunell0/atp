#include <stdio.h>
#include <stdlib.h>

 int main(){
    int* v = NULL;
    int n;
    printf("Insira o valor do tamanho do vetor:\n"); //tamanho inicial do vetor
    scanf("%d", &n);
    v = (int*) calloc(n, sizeof(int));

    if(v == NULL) return 1; //verifica se o alocamento funcionou

    for(int i=0; i < n; i++){
        printf("Digite o valor do termo da %dª posicao (use -1 para finalizar):\n", i+1);
        scanf("%d", &v[i]);
        if (v[i] == -1){
          n = i;
          break;
        } 
        realloc(v, i+1 * sizeof(int));
    }
    printf("\nVetor:\n");
    for(int i=0; i < n; i++){
        printf("%d\n", v[i]);
    }

    free(v);
    getchar();
    return 0;
 }