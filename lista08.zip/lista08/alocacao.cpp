//ARQUIVO DE APRENDIZAGEM - EXERCICIOS A PARTE

/*
     ALOCAÇÃO DINÂMICA
------------------------------
FUNÇÃO  - FUNCIONALIDADE
------------------------------
malloc  - aloca sem inicializar
calloc  - aloca e instancia com zero
realloc - redimensiona
free    - libera a memória
*/


#include <stdio.h> 
#include <stdlib.h>

int main(){
     int *v; //igual a int* (vetor de inteiro)
     int quanto;

     printf("Informe o tamanho do vetor\n");
     scanf("%d", &quanto);
      //MALLOC(TAMANHO);
     //v = (int*) malloc(quanto * sizeof(int));  //sizeof(int) retorna o tamanho de um inteiro em bytes
     
      //CALLOC(QUANTO, TAMANHO);
     //v = (int*) calloc(quanto, sizeof(int));  //sizeof(int) retorna o tamanho de um inteiro em bytes
     
       //REALLOC(VETOR, TAMANHO);
      //v = (int*) calloc(quanto, sizeof(int));//reservo 'quanto' espaco na memoria
     //realloc(v, 3 * sizeof(int)); //reservo 3 espaco na memoria


     //imprime (descomente este trecho para qualquer um dos trechos acima)
     /*
     for (int i=0; i < quanto; i++){
          printf("%d\n", v[i]); //retorna zeros
     }
     */

     //free(v); //libera a memoria (!IMPORTANT - css rs rs rs)

     getchar();
     return 0;
}