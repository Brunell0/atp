#include <stdio.h>
#include <stdlib.h>

int *new_vetor(int *p, int *tam){
     int contador = 0, j = 0;
     int* s = NULL;
     for (int i = 0; i < *tam; i++){
          if (p[i] % 2 == 0){
               contador++;
          }
     }     
     s = (int*) malloc(contador * sizeof(int));
     if(s == NULL) return NULL;
     for (int i = 0; i < *tam; i++){
          if (p[i] % 2 == 0){
               s[j] = p[i];
               j++; 
          }
     }     
     *tam -= contador + 1;
     return s;
}

 int main(){
    int* v = NULL;
    int n;
    printf("Insira o valor do tamanho do vetor:\n");
    scanf("%d", &n);
    v = (int*) malloc(n * sizeof(int));

    if(v == NULL) return 1; //verifica se o alocamento funcionou

    for(int i=0; i < n; i++){
        printf("Digite o valor do termo da %dª posicao:\n", i+1);
        scanf("%d", &v[i]);

    }
    
    v = new_vetor(v, &n);

    printf("\nVetor:\n");
    for(int i=0; i < n; i++){
        printf("%d\n", v[i]);
    }

    free(v);
    getchar();
    return 0;
 }