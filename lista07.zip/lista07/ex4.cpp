#include <stdio.h>
#include <stdlib.h>

void imprimir(int *a, int *b, int t){
    int achou = 0;
    for(int i = 0; i < t; i++){
        achou = 0;
        for (int j = 0; j < t && achou == 0; j++){
            if (a[i] == b[j]){
                printf("Valor em comum: %d\n", a[i]);
                achou = 1;
            }
        }
    }
}

int main(){
    int A[5] = {4, 2, 3, 5, 4},
    B[5] = {2, 5, 2, 3, 2},
    T = 5;
    
    imprimir(A, B, T);
    
    getchar();
    return 0;
}