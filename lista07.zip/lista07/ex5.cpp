#include <stdio.h>
#include <stdlib.h>

void inversor(int *a, int t){
    int total = t - 1;
    for (int i = 0; i < t; i++){
        printf("A[%d]: %d\n", i, a[total]);
        total--;
    }
}

int main(){
    int array[5] = {1,2,3,4,5};
    int tam = 5;
    
    printf("Array Original:\n");
    for (int i = 0; i < tam; i++){
        printf("A[%d]: %d\n", i, array[i]);
    }
    printf("\nArray Invertido:\n");
    
    inversor(array, tam);
    
    getchar();
    return 0;
}