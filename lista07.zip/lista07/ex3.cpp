#include <stdio.h>
#include <stdlib.h>

int existe(int *v, int y, int t){
    for(int i = 0 ; i < t; i++){
        if(v[i] == y){
            return 1;
        }
    }
    return 0;
}

int main(){
    int vetor[6] = {10, 2, 8, 7, 3, -1}, x, t;
    printf("Digite qual numero quer procurar dentro do vetor:\n");
    scanf("%d", &x);
    
    if (existe(vetor, x, 6)){
        printf("O valor %d existe no vetor", x); 
    }else{
        printf("O valor %d NAO existe no vetor", x); 
    }
    getchar();
    return 0;
}