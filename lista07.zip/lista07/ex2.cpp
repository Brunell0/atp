#include <stdio.h>
#include <stdlib.h>

int main(){
    int A[5] = {10, 9, 8, 7, 6}, 
    B[5] = {1, 2, 3, 4, 5};
    
    for (int i = 0; i < 5; i++){
        printf("A[%d]: %d\n", i, A[i]);
        printf("B[%d]: %d\n", i, B[i]);
    }
    getchar();
    return 0;
}