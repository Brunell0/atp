#include <stdio.h>
#include <stdlib.h>

int potencia(int base, int expoente){
     if (expoente <= 0) return 1;
     return base * potencia(base, expoente-1);
}

int main(){
     int b, e;
     
     printf("Digite a base:\n");
     scanf("%d", &b);

     printf("Digite o expoente:\n");
     scanf("%d", &e);
     
     printf("%d", potencia(b, e));
     
     getchar();
     return 0;
}