#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
     srand(time(NULL));
     printf("Aleatório entre 2 e 12: %d\n", (rand() % 11) + 2);
     getchar();
     return 0;
}