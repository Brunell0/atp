#include <stdio.h>
#include <stdlib.h>

int soma(int n){
     if (n == 1) return 1;
     return n + soma(n-1);
}

int main(){
     int val;
     printf("Digite um numero para calcular seu termial:\n");
     scanf("%d", &val);
     printf("%d", soma(val));
     getchar();
     return 0;
}