#include <stdio.h>
#include <stdlib.h>

int calcula(int n){
     if (n < 10) return 1;
     n = n / 10;
     return 1 + calcula(n);
}

int main(){
     int val;
     printf("Digite um numero para calcular quantidade de digitos:\n");
     scanf("%d", &val);
     printf("%d", calcula(val));
     getchar();
     return 0;
}