#include <stdio.h>
#include <stdlib.h>

int eh_palindromo(int x){
    int original = x, invertido = 0;

    while (x > 0) {
        int digito = x % 10; //pega ultimo digito
        invertido = invertido * 10 + digito; //inverte por passos
        x /= 10; //corta ultimo digito (pois eh int)
    }

    if (invertido == original) return 1;
    else return 0;
}

int main(){
    int a, j = 0, retorno;
    printf("Informe um numero natural:\n");
    scanf("%d", &a);
    while (a < 0){
        j++;
        
        if (j >= 10) {printf("Desisto...\n"); return 0;}
        else if (j < 3) {printf("Informe um numero POSITIVO:\n");}
        else {printf("O NUMERO DEVE SER POSITIVO!!!\n");}
        
        scanf("%d", &a);
    }
    //obtem o valor de retorno da funcao
    retorno = eh_palindromo(a);
    if (retorno == 0){ //nao eh palindromo
        printf("Nao eh palindromo!");
    }else{ //eh palindromo
        printf("Eh palindromo!");
    }
    
    return 0;
}