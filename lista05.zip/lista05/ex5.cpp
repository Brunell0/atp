#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int calcula_imc(float altura, float massa){
     float imc = massa / pow(altura, 2);
     
     if (imc >= 30){
          return 3;
     }else if (imc >= 25){
          return 2;
     }else if (imc >= 18.5){
          return 1;
     }else{ //menor que 18.5
          return 0;
     }
}

void imprima_imc(float altura, float massa){
     int resultado = calcula_imc(altura, massa);
     std::string var;
     switch(resultado){
          case 0:
               var = "Magreza";
          break;
          case 1:
               var = "Saudável";
          break;
          case 2:
               var = "Sobrepeso";
          break;
          case 3:
               var = "Obesidade";
          break;
     }
     printf("%s", var.c_str());
}


int main(){
     float alt, massa;

     printf("Informe sua altura em metros:\n");
     scanf("%f", &alt);

     printf("Informe sua massa em quilogramas:\n");
     scanf("%f", &massa);

     imprima_imc(alt, massa);

     return 0;
}