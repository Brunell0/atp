#include <stdio.h>
#include <stdlib.h>

int eh_primo(int x){
     for (int i = 2; i < x; i++){
          if (x % i == 0){
               return 0;
          }
     }
     return 1;
}

int main(){
     int a;

     printf("Defina um valor:\n");
     scanf("%d", &a);
     while (a < 2){
          printf("Defina um valor MAIOR OU IGUAL A 2:\n");
          scanf("%d", &a);
     }

     int resultado = eh_primo(a);
     switch(resultado){
          case 1:
               printf("1 (Primo)");
          break;
          case 0:
               printf("0 (Nao Primo)");
          break;
     }
     
     return 0;
}