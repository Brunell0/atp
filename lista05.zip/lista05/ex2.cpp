#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//funcao quadratica
float a, b, c;

float func_quad(float A, float B, float C, float X){
     return (pow(X, 2) * A) + (B * X) + C;
}

int main(){
     float x;

     printf("Defina valores para A, B e C:\n");
     scanf("%f", &a);
     scanf("%f", &b);
     scanf("%f", &c);
     
     printf("Defina X:\n");
     scanf("%f", &x);

     float resultado = func_quad(a, b, c, x);
     printf("Resultado: %.2f", resultado);
     return 0;
}