#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void calcular_circulo(float raio, float *area, float *perimetro){
     *area = M_PI * pow(raio, 2);
     *perimetro = 2 * M_PI * raio;
}

int main(){
     float raio, a, p;

     printf("Informe o raio:\n");
     scanf("%f", &raio);

     calcular_circulo(raio, &a, &p);
     printf("Area: %.4f\nPerimetro: %.4f\n", a, p);

     return 0;
}