#include <stdio.h>
#include <stdlib.h>

void imprime_ola(){
     printf("Ola, mundo!");
}

int main(){
     imprime_ola();
     getchar();
     return 0;
}