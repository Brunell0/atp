#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float distancia(float X1, float Y1, float X2, float Y2){
    float distancia_euclidiana = sqrt( pow(X1 - X2, 2) + pow(Y1- Y2, 2) );
    return distancia_euclidiana;
}

int main(){
    float x1, y1, x2, y2;
    printf("Informe a coordenada x1:\n");
    scanf("%f", &x1);
    printf("Informe a coordenada y1:\n");
    scanf("%f", &y1);
    printf("Informe a coordenada x2:\n");
    scanf("%f", &x2);
    printf("Informe a coordenada y2:\n");
    scanf("%f", &y2);
    
    printf("Distancia Euclidiana: %.5f\n", distancia(x1, y1, x2, y2));
    
    return 0;
}