#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float celsius_para_fahrenheit(float C){
     return (C * 9/5) + 32;
}

int main(){
     float c;

     printf("Defina um valor em graus Celsius:\n");
     scanf("%f", &c);

     float resultado = celsius_para_fahrenheit(c);
     printf("Fahrenheit: %.2f", resultado);
     return 0;
}